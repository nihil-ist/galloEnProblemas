import { Component } from '@angular/core';

@Component({
  selector: 'app-opciones',
  standalone: true,
  imports: [],
  templateUrl: './opciones.component.html',
  styleUrl: './opciones.component.css'
})
export class OpcionesComponent {

}
