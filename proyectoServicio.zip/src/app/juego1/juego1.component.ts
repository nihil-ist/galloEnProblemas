import { Component } from '@angular/core';

@Component({
  selector: 'app-juego1',
  standalone: true,
  imports: [],
  templateUrl: './juego1.component.html',
  styleUrl: './juego1.component.css'
})
export class Juego1Component {

}
